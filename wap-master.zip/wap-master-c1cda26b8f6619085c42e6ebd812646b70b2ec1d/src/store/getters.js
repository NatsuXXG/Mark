export const username = state => state.username
export const usermoney = state => state.usermoney
export const agmoney = state => state.agmoney
export const bbinmoney = state => state.bbinmoney
export const mgmoney = state => state.mgmoney
export const dsmoney = state => state.dsmoney
export const agentId = state => state.agentId
