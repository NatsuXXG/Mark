// 常量用来给mutations用
export const LOGIN = 'LOGIN'
export const LOGOUT = 'LOGOUT'
export const USERMONEY = 'USERMONEY'
export const AGMONEY = 'AGMONEY'
export const BBINMONEY = 'BBINMONEY'
export const MGMONEY = 'MGMONEY'
export const DSMONEY = 'DSMONEY'
export const AGENTID = 'AGENTID'
